# -*- coding: utf-8 -*-

n = 3  # integer number
address = "221b Baker Street, NW1 6XE, London"  # Sherlock Holmes' address
employee = {
    'age': 45,
    'role': 'CTO',
    'SSN': 'AB1234567',
}
