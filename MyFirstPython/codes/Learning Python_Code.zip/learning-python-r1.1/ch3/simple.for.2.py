surnames = ['Rivest', 'Shamir', 'Adleman']
for position in range(len(surnames)):
    print(position, surnames[position])
    # print(surnames[position][0], end='')  # try swapping prints
