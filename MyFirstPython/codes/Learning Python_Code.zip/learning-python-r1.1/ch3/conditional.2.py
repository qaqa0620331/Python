late = False
if late:
    print('I need to call my manager!')  #1
else:
    print('no need to call my manager...')  #2
