# functional-python-programming-2e
Code Examples for Functional Python Programming 2nd Edition

Requies pymonad

To confirm that the doctests all pass::

    $ python3 test_all.py

Tests must be run from the top-level directory::

    $ python3 -m doctest Chapter_3/*.py

There is no response when the tests pass.

If you want details, you can do the following::

    $ python3 -m doctest -v Chapter_4/*.py

This will produce a lot of detail, but at the end is a count of tests passed.
